package edu.jspiders.springmvc;

public class App {

}
